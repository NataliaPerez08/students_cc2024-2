package kass.concurrente.modelo.cuchillo;

public class CuchilloChef implements Cuchillo{
    public int corta(){
        return 2;
    }
}
